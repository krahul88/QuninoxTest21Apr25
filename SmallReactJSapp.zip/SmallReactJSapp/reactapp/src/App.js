
import React, { useState } from 'react';
import Form from './components/Form';
import ImageView from './components/ImageView';
import Card from './components/Card';

const App = () => {
    const [userData, setUserData] = useState(null);
    const [selectedImage, setSelectedImage] = useState(null);

    const handleFormSubmit = (data) => {
        setUserData(data);
    };

    const handleAccept = (image) => {
        setSelectedImage(image);
    };

    const handleReject = () => {
        setSelectedImage(null);
    };

    if (!userData) {
        return <Form onSubmit={handleFormSubmit} />;
    }

    if (!selectedImage) {
        return <ImageView topic={userData.preferredTopic} onAccept={handleAccept} onReject={handleReject} />;
    }

    return <Card name={userData.name} surname={userData.surname} image={selectedImage} />;
};

export default App;
