
import React, { useState, useEffect } from 'react';
import Unsplash, { toJson } from 'unsplash-js';

const unsplash = new Unsplash({ accessKey: 'YOUR_UNSPLASH_ACCESS_KEY' });

const ImageView = ({ topic, onAccept, onReject }) => {
    const [image, setImage] = useState(null);

    useEffect(() => {
        unsplash.search.photos(topic, 1, 1)
            .then(toJson)
            .then(json => {
                setImage(json.results[0]);
            });
    }, [topic]);

    if (!image) return <div>Loading...</div>;

    return (
        <div>
            <img src={image.urls.small} alt={topic} />
            <button onClick={() => onAccept(image)}>Accept</button>
            <button onClick={onReject}>Reject</button>
        </div>
    );
};

export default ImageView;
