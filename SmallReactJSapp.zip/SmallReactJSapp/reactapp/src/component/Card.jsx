
import React from 'react';

const Card = ({ name, surname, image }) => (
    <div>
        <h2>{name} {surname}</h2>
        <img src={image.urls.thumb} alt="Selected" />
    </div>
);

export default Card;
