
import React, { useState } from 'react';

const Form = ({ onSubmit }) => {
    const [name, setName] = useState('');
    const [surname, setSurname] = useState('');
    const [topic, setTopic] = useState('');
    const [customTopic, setCustomTopic] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        const preferredTopic = topic === 'Other' ? customTopic : topic;
        onSubmit({ name, surname, preferredTopic });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required />
            <input type="text" placeholder="Surname" value={surname} onChange={(e) => setSurname(e.target.value)} required />
            <select value={topic} onChange={(e) => setTopic(e.target.value)} required>
                <option value="">Select Topic</option>
                <option value="Travel">Travel</option>
                <option value="Cars">Cars</option>
                <option value="Wildlife">Wildlife</option>
                <option value="Technology">Technology</option>
                <option value="Other">Other</option>
            </select>
            {topic === 'Other' && <input type="text" placeholder="Enter your topic" value={customTopic} onChange={(e) => setCustomTopic(e.target.value)} required />}
            <button type="submit">Submit</button>
        </form>
    );
};

export default Form;
