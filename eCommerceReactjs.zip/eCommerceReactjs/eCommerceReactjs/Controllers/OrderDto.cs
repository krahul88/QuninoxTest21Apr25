﻿// OrderController.cs
public class OrderDto
{
    internal string CustomerId;
    internal IEnumerable<Order> OrderItems;

    public bool HasLoyaltyMembership { get; internal set; }
}