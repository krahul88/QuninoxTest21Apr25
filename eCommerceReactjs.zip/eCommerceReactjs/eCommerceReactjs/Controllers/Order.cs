﻿// OrderController.cs
internal class Order
{
    public int CustomerId { get; set; }
    public string OrderItems { get; set; }
}