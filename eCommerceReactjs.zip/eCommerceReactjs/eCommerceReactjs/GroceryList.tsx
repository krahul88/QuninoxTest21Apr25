﻿
// GroceryList.tsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const GroceryList: React.FC = () => {
    const [groceries, setGroceries] = useState([]);

    useEffect(() => {
        axios.get('/api/groceries').then(response => {
            setGroceries(response.data);
        });
    }, []);

    return (
        <div>
            {groceries.map(grocery => (
                <div key={grocery.id}>
                    <span>{grocery.name}</span>
                    <input type="number" min="1" />
                    <button>Add to Basket</button>
                </div>
            ))}
        </div>
    );
};

export default GroceryList;
